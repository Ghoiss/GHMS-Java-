package lgq.design.jsp.dao;

import lgq.design.jsp.model.Guest;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class GuestDao extends BaseDao<Guest> {
    @Override
    protected Guest mapRow(ResultSet rs) throws SQLException {
        Guest guest = new Guest();
        guest.setGuestId(rs.getInt("guest_id"));
        guest.setName(rs.getString("name"));
        guest.setIdCard(rs.getString("id_card"));
        guest.setPhone(rs.getString("phone"));
        guest.setEmail(rs.getString("email"));
        return guest;
    }

    public List<Guest> findAll(int offset, int limit) {
        String sql = "SELECT * FROM guests LIMIT ? OFFSET ?";
        return query(sql, limit, offset);
    }

    public Guest findById(int guestId) {
        String sql = "SELECT * FROM guests WHERE guest_id = ?";
        List<Guest> guests = query(sql, guestId);
        return guests.isEmpty() ? null : guests.get(0);
    }

    public Guest findByIdCard(String idCard) {
        String sql = "SELECT * FROM guests WHERE id_card = ?";
        List<Guest> guests = query(sql, idCard);
        return guests.isEmpty() ? null : guests.get(0);
    }

    public boolean save(Guest guest) {
        String sql = "INSERT INTO guests (name, id_card, phone, email) VALUES (?, ?, ?, ?)";
        return update(sql, 
            guest.getName(),
            guest.getIdCard(),
            guest.getPhone(),
            guest.getEmail()
        );
    }

    public boolean update(Guest guest) {
        String sql = "UPDATE guests SET name = ?, id_card = ?, phone = ?, email = ? WHERE guest_id = ?";
        return update(sql,
            guest.getName(),
            guest.getIdCard(),
            guest.getPhone(),
            guest.getEmail(),
            guest.getGuestId()
        );
    }

    public boolean delete(int guestId) {
        String sql = "DELETE FROM guests WHERE guest_id = ?";
        return update(sql, guestId);
    }

    public List<Guest> findBySearch(String keyword, int offset, int limit) {
        String sql = "SELECT * FROM guests WHERE name LIKE ? OR id_card LIKE ? OR phone LIKE ? LIMIT ? OFFSET ?";
        String pattern = "%" + keyword + "%";
        return query(sql, pattern, pattern, pattern, limit, offset);
    }

    public int count() {
        return count("SELECT COUNT(*) FROM guests");
    }

    public int countBySearch(String keyword) {
        String sql = "SELECT COUNT(*) FROM guests WHERE name LIKE ? OR id_card LIKE ? OR phone LIKE ?";
        String pattern = "%" + keyword + "%";
        return count(sql, pattern, pattern, pattern);
    }
} 
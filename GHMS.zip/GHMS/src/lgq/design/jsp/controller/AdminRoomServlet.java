package lgq.design.jsp.controller;

import lgq.design.jsp.model.Room;
import lgq.design.jsp.service.RoomService;
import lgq.design.jsp.util.PageUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/rooms/*")
public class AdminRoomServlet extends HttpServlet {
    private RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo(); //获取请求的路径信息，以便根据不同的路径执行不同的操作
        
        if (pathInfo == null || "/".equals(pathInfo)) {
            // 显示房间列表
            int page = 1;
            try {
                page = Integer.parseInt(req.getParameter("page"));// 尝试从请求参数中获取当前页码。如果请求中包含 page 参数
            } catch (NumberFormatException e) {//则将其转换为整数；如果转换失败（例如参数不是数字），则保持默认值1
                // 使用默认值1
            }
            
            String search = req.getParameter("search");//从请求中获取 search 参数，表示用户输入的搜索关键字
            PageUtil<Room> pageUtil = roomService.getRoomsByPage(page, search);//获取指定页的房间列表和相关的分页信息
            req.setAttribute("pageUtil", pageUtil);
            req.getRequestDispatcher("/jsp/admin/rooms.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            // 显示添加房间表单
            req.getRequestDispatcher("/jsp/admin/room-form.jsp").forward(req, resp);
        } else if (pathInfo.startsWith("/edit/")) {
            // 显示编辑房间表单
            int roomId = Integer.parseInt(pathInfo.substring(6));
            Room room = roomService.getRoomById(roomId);
            req.setAttribute("room", room);
            req.getRequestDispatcher("/jsp/admin/room-form.jsp").forward(req, resp);
        } else if ("/reservations".equals(pathInfo)) {
            String roomNumber = req.getParameter("roomNumber");
            String guestName = req.getParameter("guestName");
            
            List<Room> roomsWithReservations = roomService.getRoomReservations(roomNumber, guestName);
            req.setAttribute("roomsWithReservations", roomsWithReservations);
            req.getRequestDispatcher("/jsp/admin/room-reservations.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if ("/add".equals(pathInfo) || "/edit".equals(pathInfo)) {
            Room room = new Room();
            room.setRoomNumber(req.getParameter("roomNumber"));
            room.setRoomType(req.getParameter("roomType"));
            room.setPrice(Double.parseDouble(req.getParameter("price")));
            room.setStatus(req.getParameter("status"));
            room.setDescription(req.getParameter("description"));
            
            // 处理员工ID
            String employeeIdStr = req.getParameter("employeeId");
            if (employeeIdStr != null && !employeeIdStr.trim().isEmpty()) {
                room.setEmployeeId(Integer.parseInt(employeeIdStr));
            }
            
            if ("/edit".equals(pathInfo)) {
                room.setRoomId(Integer.parseInt(req.getParameter("roomId")));
                roomService.updateRoom(room);
            } else {
                roomService.addRoom(room);
            }
            resp.sendRedirect(req.getContextPath() + "/admin/rooms");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int roomId = Integer.parseInt(req.getParameter("roomId"));
        if (roomService.deleteRoom(roomId)) {
            resp.setStatus(200);
        } else {
            resp.setStatus(500);
        }
    }
} 
package lgq.design.jsp.dao;

import lgq.design.jsp.model.Room;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class RoomDao extends BaseDao<Room> {
    @Override
    protected Room mapRow(ResultSet rs) throws SQLException {
        Room room = new Room();
        room.setRoomId(rs.getInt("room_id"));
        room.setRoomNumber(rs.getString("room_number"));
        room.setRoomType(rs.getString("room_type"));
        room.setPrice(rs.getDouble("price"));
        room.setStatus(rs.getString("status"));
        room.setDescription(rs.getString("description"));
        room.setEmployeeId(rs.getInt("employee_id"));
        return room;
    }

    public List<Room> findAll(int offset, int limit) {
        String sql = "SELECT * FROM rooms LIMIT ? OFFSET ?";
        return query(sql, limit, offset);
    }

    public List<Room> findBySearch(String keyword, int offset, int limit) {
        String sql = "SELECT * FROM rooms WHERE room_number LIKE ? OR room_type LIKE ? LIMIT ? OFFSET ?";
        String pattern = "%" + keyword + "%";
        return query(sql, pattern, pattern, limit, offset);
    }

    public Room findById(int roomId) {
        String sql = "SELECT * FROM rooms WHERE room_id = ?";
        List<Room> rooms = query(sql, roomId);
        return rooms.isEmpty() ? null : rooms.get(0);
    }

    public List<Room> findByStatus(String status) {
        String sql = "SELECT * FROM rooms WHERE status = ?";
        return query(sql, status);
    }

    public boolean save(Room room) {
        String sql = "INSERT INTO rooms (room_number, room_type, price, status, description, employee_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        return update(sql, room.getRoomNumber(), room.getRoomType(), room.getPrice(), 
                     room.getStatus(), room.getDescription(), room.getEmployeeId());
    }

    public boolean update(Room room) {
        String sql = "UPDATE rooms SET room_number = ?, room_type = ?, price = ?, " +
                    "status = ?, description = ?, employee_id = ? WHERE room_id = ?";
        return update(sql, room.getRoomNumber(), room.getRoomType(), room.getPrice(), 
                     room.getStatus(), room.getDescription(), room.getEmployeeId(), room.getRoomId());
    }

    public boolean delete(int roomId) {
        String sql = "DELETE FROM rooms WHERE room_id = ?";
        return update(sql, roomId);
    }

    public int count() {
        return count("SELECT COUNT(*) FROM rooms");
    }

    public int countBySearch(String keyword) {
        String pattern = "%" + keyword + "%";
        return count("SELECT COUNT(*) FROM rooms WHERE room_number LIKE ? OR room_type LIKE ?", 
                    pattern, pattern);
    }

    public List<Room> findRoomReservations(String roomNumber, String guestName) {
        String sql = "SELECT r.*, g.guest_id, g.name AS guest_name, res.check_in_date, res.check_out_date " +
                     "FROM rooms r " +
                     "JOIN reservations res ON r.room_id = res.room_id " +
                     "JOIN guests g ON res.guest_id = g.guest_id " +
                     "WHERE r.room_number LIKE ? and g.name LIKE ?";
        String roomPattern = "%" + roomNumber + "%";
        String guestPattern = "%" + guestName + "%";
        return query(sql, roomPattern, guestPattern);
    }
}
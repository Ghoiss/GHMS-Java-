package lgq.design.jsp.dao;

import lgq.design.jsp.model.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserDao extends BaseDao<User> {
    @Override
    protected User mapRow(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        user.setPhone(rs.getString("phone"));
        user.setRole(rs.getString("role"));
        return user;
    }

    public List<User> findAll(int offset, int limit) {
        String sql = "SELECT * FROM users LIMIT ? OFFSET ?";
        return query(sql, limit, offset);
    }

    public User findByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        List<User> users = query(sql, username);
        return users.isEmpty() ? null : users.get(0);
    }

    public User findById(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        List<User> users = query(sql, userId);
        return users.isEmpty() ? null : users.get(0);
    }

    public boolean save(User user) {
        String sql = "INSERT INTO users (username, password, role, email, phone) VALUES (?, ?, ?, ?, ?)";
        return update(sql, user.getUsername(), user.getPassword(), user.getRole(), 
                     user.getEmail(), user.getPhone());
    }

    public boolean update(User user) {
        String sql = "UPDATE users SET password = ?, role = ?, email = ?, phone = ? WHERE user_id = ?";
        return update(sql, user.getPassword(), user.getRole(), user.getEmail(), 
                     user.getPhone(), user.getUserId());
    }
}
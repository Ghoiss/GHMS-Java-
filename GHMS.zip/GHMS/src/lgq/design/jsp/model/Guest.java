package lgq.design.jsp.model;

import java.util.Date;

public class Guest {
    private Integer guestId;
    private String name;
    private String idCard;
    private String phone;
    private String email;
    private Date createTime;

    // 构造方法
    public Guest() {}

    public Guest(Integer guestId, String name, String idCard, String phone, String email) {
        this.guestId = guestId;
        this.name = name;
        this.idCard = idCard;
        this.phone = phone;
        this.email = email;
        this.createTime = new Date();
    }

    public Integer getGuestId() {
        return guestId;
    }

    public void setGuestId(Integer guestId) {
        this.guestId = guestId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
package lgq.design.jsp.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Reservation {
    private Integer reservationId;
    private Integer guestId;
    private Integer roomId;
    private Integer userId;
    private Date checkInDate;
    private Date checkOutDate;
    private String status;
    private Timestamp createTime;

    // 构造方法
    public Reservation() {}

    public Reservation(Integer reservationId, Integer guestId, Integer roomId, Integer userId, 
                      Date checkInDate, Date checkOutDate, String status, Timestamp createTime) {
        this.reservationId = reservationId;
        this.guestId = guestId;
        this.roomId = roomId;
        this.userId = userId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.status = status;
        this.createTime = createTime;
    }

    // Getter和Setter方法
    public Integer getReservationId() {
        return reservationId;
    }

    public void setReservationId(Integer reservationId) {
        this.reservationId = reservationId;
    }

    public Integer getGuestId() {
        return guestId;
    }

    public void setGuestId(Integer guestId) {
        this.guestId = guestId;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }
}
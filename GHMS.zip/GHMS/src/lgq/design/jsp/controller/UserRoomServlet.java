package lgq.design.jsp.controller;

import lgq.design.jsp.model.Room;
import lgq.design.jsp.service.RoomService;
import lgq.design.jsp.util.PageUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/rooms")
public class UserRoomServlet extends HttpServlet {
    private RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException e) {
            // 使用默认值1
        }
        
        String search = req.getParameter("search");
        PageUtil<Room> pageUtil = roomService.getRoomsByPage(page, search);
        req.setAttribute("pageUtil", pageUtil);
        req.getRequestDispatcher("/jsp/user/rooms.jsp").forward(req, resp);
    }
} 
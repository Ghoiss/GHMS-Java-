package lgq.design.jsp.service;

import lgq.design.jsp.dao.UserDao;
import lgq.design.jsp.model.User;
import lgq.design.jsp.util.PasswordUtil;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    private UserDao userDao = new UserDao();

    // 初始化管理员账户
    public void initAdmin() {
        User admin = userDao.findByUsername("admin");
        if (admin == null) {
            User adminUser = new User();
            adminUser.setUsername("admin");
            adminUser.setPassword(PasswordUtil.encrypt("123")); // 使用加密后的密码
            adminUser.setRole("ADMIN");
            adminUser.setEmail("admin@example.com");
            adminUser.setPhone("13800000000");
            userDao.save(adminUser);
        }
    }

    public User login(String username, String password) {
        User user = userDao.findByUsername(username);
        if (user != null && PasswordUtil.verify(password, user.getPassword())) {
            return user;
        }
        return null;
    }

    public boolean register(User user) {
        // 检查用户名是否已存在
        if (userDao.findByUsername(user.getUsername()) != null) {
            return false;
        }
        
        // 加密密码
        user.setPassword(PasswordUtil.encrypt(user.getPassword()));
        
        // 设置默认角色
        if (user.getRole() == null) {
            user.setRole("USER");
        }
        
        return userDao.save(user);
    }

    public User getUserById(int userId) {
        return userDao.findById(userId);
    }

    public boolean updateUser(User user) {
        // 如果要更新密码，需要先加密
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            user.setPassword(PasswordUtil.encrypt(user.getPassword()));
        }
        return userDao.update(user);
    }

    // 添加获取所有用户的方法
    public List<User> getAllUsers() {
        try {
            return userDao.findAll(0, Integer.MAX_VALUE);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();  // 返回空列表而不是 null
        }
    }
}
package lgq.design.jsp.service;

import lgq.design.jsp.dao.ReservationDao;
import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.util.PageUtil;

import java.util.List;

public class ReservationService {
    private ReservationDao reservationDao = new ReservationDao();
    private RoomService roomService = new RoomService();

    public PageUtil<Reservation> getAllReservations(int page) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Reservation> reservations = reservationDao.findAll(offset, pageSize);
        int totalRecords = reservationDao.count();
        
        PageUtil<Reservation> pageUtil = new PageUtil<>();
        pageUtil.setRecords(reservations);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public PageUtil<Reservation> getUserReservations(int userId, int page) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Reservation> reservations = reservationDao.findByUserId(userId, offset, pageSize);
        int totalRecords = reservationDao.countByUserId(userId);
        
        PageUtil<Reservation> pageUtil = new PageUtil<>();
        pageUtil.setRecords(reservations);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public boolean createReservation(Reservation reservation) {
        // 检查房间是否可用
        if (!roomService.updateRoomStatus(reservation.getRoomId(), "RESERVED")) {
            return false;
        }
        return reservationDao.save(reservation);
    }

    public boolean checkIn(int reservationId) {
        Reservation reservation = reservationDao.findById(reservationId);
        if (reservation != null) {
            reservation.setStatus("CHECKED_IN");
            roomService.updateRoomStatus(reservation.getRoomId(), "OCCUPIED");
            return reservationDao.update(reservation);
        }
        return false;
    }

    public boolean checkOut(int reservationId) {
        Reservation reservation = reservationDao.findById(reservationId);
        if (reservation != null) {
            reservation.setStatus("COMPLETED");
            roomService.updateRoomStatus(reservation.getRoomId(), "AVAILABLE");
            return reservationDao.update(reservation);
        }
        return false;
    }

    public boolean updateReservationStatus(int reservationId, String status) {
        Reservation reservation = reservationDao.findById(reservationId);
        if (reservation != null) {
            reservation.setStatus(status);
            return reservationDao.update(reservation);
        }
        return false;
    }

    public List<Reservation> getAllReservations() {
        return reservationDao.findAll(0, Integer.MAX_VALUE);
    }

    public boolean deleteReservation(int reservationId) {
        Reservation reservation = reservationDao.findById(reservationId);
        if (reservation != null) {
            // 如果房间处于预订或入住状态，需要将房间状态改回可用
            if ("PENDING".equals(reservation.getStatus()) || 
                "CHECKED_IN".equals(reservation.getStatus())) {
                roomService.updateRoomStatus(reservation.getRoomId(), "AVAILABLE");
            }
            return reservationDao.delete(reservationId);
        }
        return false;
    }
}
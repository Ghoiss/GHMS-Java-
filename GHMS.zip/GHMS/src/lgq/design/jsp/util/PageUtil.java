package lgq.design.jsp.util;

import java.util.ArrayList;
import java.util.List;

public class PageUtil<T> {
    private int pageSize = 10;    // 每页显示记录数
    private int currentPage = 1;   // 当前页码
    private int totalRecords;     // 总记录数
    private List<T> records;      // 当前页的数据记录
    
    // 无参构造函数
    public PageUtil() {
        this.records = new ArrayList<>();
    }//初始化 records 为一个空的 ArrayList，用于创建一个空的分页对象
    
    // 带参构造函数
    public PageUtil(List<T> records, int currentPage, int pageSize, int totalRecords) {
        this.records = records != null ? records : new ArrayList<>();
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalRecords = totalRecords;
    }
    
    // 获取总页数
    public int getTotalPages() {
        return (totalRecords + pageSize - 1) / pageSize;//确保了向上取整的效果，避免了因整除导致的页数不足
    }

    // Getter和Setter方法
    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public List<T> getRecords() {
        return records;
    }

    public void setRecords(List<T> records) {
        this.records = records != null ? records : new ArrayList<>();
    }
}
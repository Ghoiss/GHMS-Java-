package lgq.design.jsp.controller;

import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.model.User;
import lgq.design.jsp.service.ReservationService;
import lgq.design.jsp.util.PageUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/user/reservations")
public class UserReservationServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException e) {
            // 使用默认值1
        }
        
        PageUtil<Reservation> pageUtil = reservationService.getUserReservations(user.getUserId(), page);
        req.setAttribute("pageUtil", pageUtil);
        req.getRequestDispatcher("/jsp/user/reservations.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        
        Reservation reservation = new Reservation();
        reservation.setRoomId(Integer.parseInt(req.getParameter("roomId")));
        reservation.setUserId(user.getUserId());
        reservation.setCheckInDate(Date.valueOf(req.getParameter("checkInDate")));
        reservation.setCheckOutDate(Date.valueOf(req.getParameter("checkOutDate")));
        reservation.setStatus("PENDING");
        
        reservationService.createReservation(reservation);
        resp.sendRedirect(req.getContextPath() + "/user/reservations");
    }
} 
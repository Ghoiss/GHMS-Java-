package lgq.design.jsp.dao;

import lgq.design.jsp.model.Reservation;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ReservationDao extends BaseDao<Reservation> {
    @Override
    protected Reservation mapRow(ResultSet rs) throws SQLException {
        Reservation reservation = new Reservation();
        reservation.setReservationId(rs.getInt("reservation_id"));
        reservation.setGuestId(rs.getInt("guest_id"));
        reservation.setRoomId(rs.getInt("room_id"));
        reservation.setUserId(rs.getInt("user_id"));
        reservation.setCheckInDate(rs.getDate("check_in_date"));
        reservation.setCheckOutDate(rs.getDate("check_out_date"));
        reservation.setStatus(rs.getString("status"));
        reservation.setCreateTime(rs.getTimestamp("create_time"));
        return reservation;
    }

    public List<Reservation> findAll(int offset, int limit) {
        String sql = "SELECT * FROM reservations ORDER BY create_time DESC LIMIT ? OFFSET ?";
        return query(sql, limit, offset);
    }

    public List<Reservation> findByUserId(int userId, int offset, int limit) {
        String sql = "SELECT * FROM reservations WHERE user_id = ? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        return query(sql, userId, limit, offset);
    }

    public Reservation findById(int reservationId) {
        String sql = "SELECT * FROM reservations WHERE reservation_id = ?";
        List<Reservation> reservations = query(sql, reservationId);
        return reservations.isEmpty() ? null : reservations.get(0);
    }

    public boolean save(Reservation reservation) {
        String sql = "INSERT INTO reservations (guest_id, room_id, user_id, check_in_date, check_out_date, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        return update(sql, 
            reservation.getGuestId(),
            reservation.getRoomId(),
            reservation.getUserId(),
            reservation.getCheckInDate(),
            reservation.getCheckOutDate(),
            reservation.getStatus()
        );
    }

    public boolean update(Reservation reservation) {
        String sql = "UPDATE reservations SET guest_id = ?, room_id = ?, check_in_date = ?, " +
                    "check_out_date = ?, status = ? WHERE reservation_id = ?";
        return update(sql,
            reservation.getGuestId(),
            reservation.getRoomId(),
            reservation.getCheckInDate(),
            reservation.getCheckOutDate(),
            reservation.getStatus(),
            reservation.getReservationId()
        );
    }

    public int count() {
        return count("SELECT COUNT(*) FROM reservations");
    }

    public int countByUserId(int userId) {
        return count("SELECT COUNT(*) FROM reservations WHERE user_id = ?", userId);
    }

    public List<Reservation> findBySearch(String keyword, int offset, int limit) {
        String sql = "SELECT r.* FROM reservations r " +
                    "JOIN guests g ON r.guest_id = g.guest_id " +
                    "WHERE g.name LIKE ? OR g.id_card LIKE ? " +
                    "ORDER BY r.create_time DESC LIMIT ? OFFSET ?";
        String pattern = "%" + keyword + "%";
        return query(sql, pattern, pattern, limit, offset);
    }

    public int countBySearch(String keyword) {
        String sql = "SELECT COUNT(*) FROM reservations r " +
                    "JOIN guests g ON r.guest_id = g.guest_id " +
                    "WHERE g.name LIKE ? OR g.id_card LIKE ?";
        String pattern = "%" + keyword + "%";
        return count(sql, pattern, pattern);
    }

    public boolean delete(int reservationId) {
        String sql = "DELETE FROM reservations WHERE reservation_id = ?";
        return update(sql, reservationId);
    }
}

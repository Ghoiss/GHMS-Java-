package lgq.design.jsp.test;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/test-poi")
public class TestPoiServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        
        try {
            // 尝试创建一个简单的Excel工作簿
            Workbook workbook = new HSSFWorkbook();
            Sheet sheet = workbook.createSheet("Test Sheet");
            Row row = sheet.createRow(0);
            Cell cell = row.createCell(0);
            cell.setCellValue("Test Success");
            

            out.println("<p style='color: green;'>POI 依赖加载成功！</p>");

        } catch (Exception e) {

            out.println("<p style='color: red;'>POI 依赖加载失败：" + e.getMessage() + "</p>");
            e.printStackTrace(out);
        }
    }
} 
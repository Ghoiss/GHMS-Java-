package lgq.design.jsp.controller;

import lgq.design.jsp.service.*;
import lgq.design.jsp.model.*;
import lgq.design.jsp.util.ExcelExportUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;

@WebServlet("/admin/export/*")
public class ExportServlet extends HttpServlet {
    private RoomService roomService = new RoomService();
    private ReservationService reservationService = new ReservationService();
    private EmployeeService employeeService = new EmployeeService();
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String pathInfo = req.getPathInfo();
        String filename = "";
        HSSFWorkbook workbook = null;
        OutputStream out = null;

        try {
            System.out.println("开始处理导出请求：" + pathInfo);
            
            if ("/rooms".equals(pathInfo)) {
                List<Room> rooms = roomService.getAllRooms();
                System.out.println("获取到房间数据：" + (rooms != null ? rooms.size() : 0) + "条");
                if (rooms != null && !rooms.isEmpty()) {
                    workbook = ExcelExportUtil.exportRooms(rooms);
                    filename = "房间信息.xls";
                }
            } else if ("/reservations".equals(pathInfo)) {
                List<Reservation> reservations = reservationService.getAllReservations();
                System.out.println("获取到预订数据：" + (reservations != null ? reservations.size() : 0) + "条");
                if (reservations != null && !reservations.isEmpty()) {
                    workbook = ExcelExportUtil.exportReservations(reservations);
                    filename = "预订信息.xls";
                }
            } else if ("/employees".equals(pathInfo)) {
                List<Employee> employees = employeeService.getAllEmployees();
                System.out.println("获取到员工数据：" + (employees != null ? employees.size() : 0) + "条");
                if (employees != null && !employees.isEmpty()) {
                    workbook = ExcelExportUtil.exportEmployees(employees);
                    filename = "员工信息.xls";
                }
            } else if ("/guests".equals(pathInfo)) {
                List<User> users = userService.getAllUsers();
                System.out.println("获取到客人数据：" + (users != null ? users.size() : 0) + "条");
                if (users != null && !users.isEmpty()) {
                    workbook = ExcelExportUtil.exportGuests(users);
                    filename = "客人信息.xls";
                }
            }

            if (workbook != null) {
                System.out.println("准备写入Excel文件：" + filename);
                
                filename = new String(filename.getBytes("UTF-8"), "ISO-8859-1");
                
                resp.reset();
                resp.setContentType("application/vnd.ms-excel;charset=UTF-8");
                resp.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
                resp.setHeader("Pragma", "public");
                resp.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
                
                try {
                    out = new BufferedOutputStream(resp.getOutputStream());
                    workbook.write(out);
                    out.flush();
                    System.out.println("Excel文件写入完成");
                } finally {
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else {
                System.out.println("没有找到数据，返回404错误");
                resp.setContentType("text/html;charset=UTF-8");
                resp.getWriter().println("没有找到数据或导出失败");
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            System.out.println("导出过程中发生错误：" + e.getMessage());
            e.printStackTrace();
            resp.setContentType("text/html;charset=UTF-8");
            resp.getWriter().println("导出失败：" + e.getMessage());
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
} 
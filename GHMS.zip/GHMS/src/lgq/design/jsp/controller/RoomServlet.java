package lgq.design.jsp.controller;

import lgq.design.jsp.model.Room;
import lgq.design.jsp.service.RoomService;
import lgq.design.jsp.util.PageUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/rooms/*")
public class RoomServlet extends HttpServlet {
    private RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if (pathInfo == null || "/".equals(pathInfo)) {
            // 用户浏览房间列表
            int page = 1;
            try {
                page = Integer.parseInt(req.getParameter("page"));
            } catch (NumberFormatException e) {
                // 使用默认值1
            }
            
            String search = req.getParameter("search");
            PageUtil<Room> pageUtil = roomService.getRoomsByPage(page, search);
            req.setAttribute("pageUtil", pageUtil);
            // 修改为用户的房间列表页面
            req.getRequestDispatcher("/jsp/user/rooms.jsp").forward(req, resp);
        }
    }
}
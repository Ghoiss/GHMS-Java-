package lgq.design.jsp.controller;

import lgq.design.jsp.model.Guest;
import lgq.design.jsp.service.GuestService;
import lgq.design.jsp.util.PageUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/guests/*")
public class AdminGuestServlet extends HttpServlet {
    private GuestService guestService = new GuestService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException e) {
            // 使用默认值1
        }
        
        String search = req.getParameter("search");
        PageUtil<Guest> pageUtil = guestService.getGuestsByPage(page, search);
        req.setAttribute("pageUtil", pageUtil);
        req.getRequestDispatcher("/jsp/admin/guests.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("delete".equals(action)) {
            int guestId = Integer.parseInt(req.getParameter("guestId"));
            guestService.deleteGuest(guestId);
            resp.setStatus(200);
        }
    }
} 
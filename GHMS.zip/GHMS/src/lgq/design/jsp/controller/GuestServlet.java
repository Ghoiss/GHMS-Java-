package lgq.design.jsp.controller;

import lgq.design.jsp.model.Guest;
import lgq.design.jsp.service.GuestService;
import lgq.design.jsp.util.PageUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/guests/*")
public class GuestServlet extends HttpServlet {
    private GuestService guestService = new GuestService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if (pathInfo == null || "/".equals(pathInfo)) {
            int page = 1;
            try {
                page = Integer.parseInt(req.getParameter("page"));
            } catch (NumberFormatException e) {
                // 使用默认值1
            }
            
            String search = req.getParameter("search");
            PageUtil<Guest> pageUtil = guestService.getGuestsByPage(page, search);
            req.setAttribute("pageUtil", pageUtil);
            req.getRequestDispatcher("/jsp/admin/guests.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            req.getRequestDispatcher("/jsp/admin/guest-form.jsp").forward(req, resp);
        } else if (pathInfo.startsWith("/edit/")) {
            int guestId = Integer.parseInt(pathInfo.substring(6));
            Guest guest = guestService.getGuestById(guestId);
            req.setAttribute("guest", guest);
            req.getRequestDispatcher("/jsp/admin/guest-form.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if ("/add".equals(pathInfo) || "/edit".equals(pathInfo)) {
            Guest guest = new Guest();
            guest.setName(req.getParameter("name"));
            guest.setIdCard(req.getParameter("idCard"));
            guest.setPhone(req.getParameter("phone"));
            guest.setEmail(req.getParameter("email"));
            
            if ("/add".equals(pathInfo)) {
                guestService.addGuest(guest);
            } else {
                guest.setGuestId(Integer.parseInt(req.getParameter("guestId")));
                guestService.updateGuest(guest);
            }
        }
        
        resp.sendRedirect(req.getContextPath() + "/admin/guests");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int guestId = Integer.parseInt(req.getParameter("guestId"));
        guestService.deleteGuest(guestId);
        resp.setStatus(200);
    }
} 
package lgq.design.jsp.util;

import java.io.PrintWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.util.List;

public class ExcelUtil {
    
    public static <T> void exportToExcel(List<T> data, OutputStream out, String sheetName) {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8"))) {
            if (data == null || data.isEmpty()) {
                return;
            }
            
            // 获取对象的所有字段
            Field[] fields = data.get(0).getClass().getDeclaredFields();
            
            // 写入标题行
            StringBuilder header = new StringBuilder();
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) {
                    header.append(",");
                }
                header.append(fields[i].getName());
            }
            writer.println(header.toString());
            
            // 写入数据行
            for (T item : data) {
                StringBuilder row = new StringBuilder();
                for (int i = 0; i < fields.length; i++) {
                    if (i > 0) {
                        row.append(",");
                    }
                    fields[i].setAccessible(true);
                    Object value = fields[i].get(item);
                    row.append(value != null ? value.toString().replace(",", ";") : "");
                }
                writer.println(row.toString());
            }
            
            writer.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
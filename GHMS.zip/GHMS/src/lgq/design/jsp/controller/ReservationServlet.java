package lgq.design.jsp.controller;

import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.model.Room;
import lgq.design.jsp.model.User;
import lgq.design.jsp.service.ReservationService;
import lgq.design.jsp.service.RoomService;
import lgq.design.jsp.util.PageUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/user/reservation/*")
public class ReservationServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        String roomId = req.getParameter("roomId");
        
        // 如果有 roomId 参数，说明是要显示预订表单
        if (roomId != null) {
            // 显示预订表单
            Room room = roomService.getRoomById(Integer.parseInt(roomId));
            
            if (room != null && "AVAILABLE".equals(room.getStatus())) {
                req.setAttribute("room", room);
                req.getRequestDispatcher("/jsp/user/reservation.jsp").forward(req, resp);
            } else {
                resp.sendRedirect(req.getContextPath() + "/user/rooms");
            }
        } else {
            // 显示用户的预订列表
            HttpSession session = req.getSession();
            User user = (User) session.getAttribute("user");
            
            int page = 1;
            try {
                page = Integer.parseInt(req.getParameter("page"));
            } catch (NumberFormatException e) {
                // 使用默认值1
            }
            
            PageUtil<Reservation> pageUtil;
            if ("ADMIN".equals(user.getRole())) {
                pageUtil = reservationService.getAllReservations(page);
                req.setAttribute("pageUtil", pageUtil);
                req.getRequestDispatcher("/jsp/admin/reservations.jsp").forward(req, resp);
            } else {
                pageUtil = reservationService.getUserReservations(user.getUserId(), page);
                req.setAttribute("pageUtil", pageUtil);
                req.getRequestDispatcher("/jsp/user/reservations.jsp").forward(req, resp);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        
        // 创建新预订
        Reservation reservation = new Reservation();
        reservation.setRoomId(Integer.parseInt(req.getParameter("roomId")));
        reservation.setUserId(user.getUserId());
        reservation.setCheckInDate(Date.valueOf(req.getParameter("checkInDate")));
        reservation.setCheckOutDate(Date.valueOf(req.getParameter("checkOutDate")));
        reservation.setStatus("PENDING");
        
        if (reservationService.createReservation(reservation)) {
            // 更新房间状态
            Room room = roomService.getRoomById(reservation.getRoomId());
            room.setStatus("RESERVED");
            roomService.updateRoom(room);
            
            if ("ADMIN".equals(user.getRole())) {
                resp.sendRedirect(req.getContextPath() + "/admin/reservations");
            } else {
                resp.sendRedirect(req.getContextPath() + "/user/reservations");
            }
        } else {
            req.setAttribute("error", "预订失败，请重试");
            doGet(req, resp);
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int reservationId = Integer.parseInt(req.getParameter("reservationId"));
        String status = req.getParameter("status");
        
        if (reservationService.updateReservationStatus(reservationId, status)) {
            resp.setStatus(HttpServletResponse.SC_OK);
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
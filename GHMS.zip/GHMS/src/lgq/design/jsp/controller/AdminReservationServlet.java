package lgq.design.jsp.controller;

import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.service.ReservationService;
import lgq.design.jsp.util.PageUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/reservations/*")
public class AdminReservationServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException e) {
            // 使用默认值1
        }
        
        PageUtil<Reservation> pageUtil = reservationService.getAllReservations(page);
        req.setAttribute("pageUtil", pageUtil);
        req.getRequestDispatcher("/jsp/admin/reservations.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String action = req.getParameter("action");
        int reservationId = Integer.parseInt(req.getParameter("reservationId"));
        
        boolean success = false;
        if ("checkin".equals(action)) {
            success = reservationService.checkIn(reservationId);
        } else if ("checkout".equals(action)) {
            success = reservationService.checkOut(reservationId);
        } else if ("cancel".equals(action)) {
            success = reservationService.updateReservationStatus(reservationId, "CANCELLED");
        } else if ("delete".equals(action)) {
            success = reservationService.deleteReservation(reservationId);
        }
        
        if (success) {
            resp.setStatus(200);
        } else {
            resp.setStatus(500);
        }
    }
} 
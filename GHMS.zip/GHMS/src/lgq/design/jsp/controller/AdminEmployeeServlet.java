package lgq.design.jsp.controller;

import lgq.design.jsp.model.Employee;
import lgq.design.jsp.service.EmployeeService;
import lgq.design.jsp.util.PageUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/employees/*")
public class AdminEmployeeServlet extends HttpServlet {
    private EmployeeService employeeService = new EmployeeService();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if (pathInfo == null || "/".equals(pathInfo)) {
            // 显示员工列表
            int page = 1;
            try {
                page = Integer.parseInt(req.getParameter("page"));
            } catch (NumberFormatException e) {
                // 使用默认值1
            }
            
            PageUtil<Employee> pageUtil = employeeService.getEmployeesByPage(page);
            req.setAttribute("pageUtil", pageUtil);
            req.getRequestDispatcher("/jsp/admin/employees.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            // 显示添加员工表单
            req.getRequestDispatcher("/jsp/admin/employee-form.jsp").forward(req, resp);
        } else if (pathInfo.startsWith("/edit/")) {
            // 显示编辑员工表单
            int employeeId = Integer.parseInt(pathInfo.substring(6));
            Employee employee = employeeService.getEmployeeById(employeeId);
            req.setAttribute("employee", employee);
            req.getRequestDispatcher("/jsp/admin/employee-form.jsp").forward(req, resp);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        
        if ("/add".equals(pathInfo) || "/edit".equals(pathInfo)) {
            Employee employee = new Employee();
            employee.setName(req.getParameter("name"));
            employee.setPhone(req.getParameter("phone"));
            
            if ("/edit".equals(pathInfo)) {
                employee.setEmployeeId(Integer.parseInt(req.getParameter("employeeId")));
                employeeService.updateEmployee(employee);
            } else {
                employeeService.addEmployee(employee);
            }
            resp.sendRedirect(req.getContextPath() + "/admin/employees");
        }
    }
    
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        int employeeId = Integer.parseInt(req.getParameter("employeeId"));
        if (employeeService.deleteEmployee(employeeId)) {
            resp.setStatus(HttpServletResponse.SC_OK);
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
} 
package lgq.design.jsp.service;

import lgq.design.jsp.dao.GuestDao;
import lgq.design.jsp.dao.ReservationDao;
import lgq.design.jsp.dao.RoomDao;
import lgq.design.jsp.model.Guest;
import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.model.Room;
import lgq.design.jsp.util.PageUtil;

import java.util.List;

public class SearchService {
    private RoomDao roomDao = new RoomDao();
    private GuestDao guestDao = new GuestDao();
    private ReservationDao reservationDao = new ReservationDao();

    public PageUtil<Room> searchRooms(String keyword, int page) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Room> rooms = roomDao.findBySearch(keyword, offset, pageSize);
        int totalRecords = roomDao.countBySearch(keyword);
        
        PageUtil<Room> pageUtil = new PageUtil<>();
        pageUtil.setRecords(rooms);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public PageUtil<Guest> searchGuests(String keyword, int page) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Guest> guests = guestDao.findBySearch(keyword, offset, pageSize);
        int totalRecords = guestDao.countBySearch(keyword);
        
        PageUtil<Guest> pageUtil = new PageUtil<>();
        pageUtil.setRecords(guests);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public PageUtil<Reservation> searchReservations(String keyword, int page) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Reservation> reservations = reservationDao.findBySearch(keyword, offset, pageSize);
        int totalRecords = reservationDao.countBySearch(keyword);
        
        PageUtil<Reservation> pageUtil = new PageUtil<>();
        pageUtil.setRecords(reservations);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }
} 
package lgq.design.jsp.filter;

import lgq.design.jsp.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        
        String path = req.getRequestURI().substring(req.getContextPath().length());
        
        // 检查是否是公共资源或登录相关页面
        if (isPublicResource(path) || isAuthPage(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // 检查会话是否存在
        if (session == null || session.getAttribute("user") == null) {
            if (isExportRequest(path)) {
                // 对于导出请求，返回JSON错误
                resp.setContentType("application/json;charset=UTF-8");
                resp.getWriter().write("{\"error\": \"请先登录\"}");
                return;
            }
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        
        // 检查管理员权限
        User user = (User) session.getAttribute("user");
        if (path.startsWith("/admin/") && !"ADMIN".equals(user.getRole())) {
            if (isExportRequest(path)) {
                // 对于导出请求，返回JSON错误
                resp.setContentType("application/json;charset=UTF-8");
                resp.getWriter().write("{\"error\": \"没有权限\"}");
                return;
            }
            resp.sendRedirect(req.getContextPath() + "/user/dashboard");
            return;
        }
        
        // 对于导出请求，设置特殊的响应头
        if (isExportRequest(path)) {
            resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            resp.setHeader("Pragma", "no-cache");
            resp.setHeader("Expires", "0");
            // 允许跨域请求
            resp.setHeader("Access-Control-Allow-Origin", "*");
            resp.setHeader("Access-Control-Allow-Methods", "GET");
            resp.setHeader("Access-Control-Allow-Headers", "Content-Type");
        }
        
        chain.doFilter(request, response);
    }
    
    private boolean isPublicResource(String path) {
        return path.startsWith("/css/") || 
               path.startsWith("/js/") || 
               path.startsWith("/images/");
    }
    
    private boolean isAuthPage(String path) {
        return path.equals("/login") || 
               path.equals("/register") || 
               path.equals("/jsp/login.jsp") || 
               path.equals("/jsp/register.jsp");
    }
    
    private boolean isExportRequest(String path) {
        return path.startsWith("/admin/export/");
    }
    
    private boolean isAjaxRequest(HttpServletRequest request) {
        return "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
} 
package lgq.design.jsp.model;

public class Employee {
    private Integer employeeId;
    private String name;
    private String phone;
    
    public Employee() {}
    
    public Employee(Integer employeeId, String name, String phone) {
        this.employeeId = employeeId;
        this.name = name;
        this.phone = phone;
    }
    
    public Integer getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
} 
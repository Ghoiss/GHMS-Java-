package lgq.design.jsp.service;

import lgq.design.jsp.dao.RoomDao;
import lgq.design.jsp.model.Room;
import lgq.design.jsp.util.PageUtil;

import java.util.List;

public class RoomService {
    private RoomDao roomDao = new RoomDao();

    public PageUtil<Room> getRoomsByPage(int page, String search) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Room> rooms;// 获取指定页的房间信息
        int totalRecords;// 获取总记录数
        
        if (search != null && !search.trim().isEmpty()) {
            rooms = roomDao.findBySearch(search, offset, pageSize);
            totalRecords = roomDao.countBySearch(search);
        } else {
            rooms = roomDao.findAll(offset, pageSize);
            totalRecords = roomDao.count();
        }
        
        PageUtil<Room> pageUtil = new PageUtil<>();
        pageUtil.setRecords(rooms);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public Room getRoomById(int roomId) {
        return roomDao.findById(roomId);
    }

    public boolean addRoom(Room room) {
        return roomDao.save(room);
    }

    public boolean updateRoom(Room room) {
        return roomDao.update(room);
    }

    public boolean deleteRoom(int roomId) {
        return roomDao.delete(roomId);
    }

    public List<Room> getAvailableRooms() {
        return roomDao.findByStatus("AVAILABLE");
    }

    public boolean updateRoomStatus(int roomId, String status) {
        Room room = roomDao.findById(roomId);
        if (room != null) {
            room.setStatus(status);
            return roomDao.update(room);
        }
        return false;
    }

    public List<Room> getAllRooms() {
        return roomDao.findAll(0, Integer.MAX_VALUE);
    }

    public List<Room> getRoomReservations(String roomNumber, String guestName) {
        return roomDao.findRoomReservations(roomNumber, guestName);
    }
}
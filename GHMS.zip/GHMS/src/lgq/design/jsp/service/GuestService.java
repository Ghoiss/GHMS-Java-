package lgq.design.jsp.service;

import lgq.design.jsp.dao.GuestDao;
import lgq.design.jsp.model.Guest;
import lgq.design.jsp.util.PageUtil;

import java.util.List;

public class GuestService {
    private GuestDao guestDao = new GuestDao();

    public PageUtil<Guest> getGuestsByPage(int page, String search) {
        int pageSize = 10;
        int offset = (page - 1) * pageSize;
        
        List<Guest> guests;
        int totalRecords;
        
        if (search != null && !search.trim().isEmpty()) {
            guests = guestDao.findBySearch(search, offset, pageSize);
            totalRecords = guestDao.countBySearch(search);
        } else {
            guests = guestDao.findAll(offset, pageSize);
            totalRecords = guestDao.count();
        }
        
        PageUtil<Guest> pageUtil = new PageUtil<>();
        pageUtil.setRecords(guests);
        pageUtil.setCurrentPage(page);
        pageUtil.setTotalRecords(totalRecords);
        
        return pageUtil;
    }

    public Guest getGuestById(int guestId) {
        return guestDao.findById(guestId);
    }

    public boolean addGuest(Guest guest) {
        return guestDao.save(guest);
    }

    public boolean updateGuest(Guest guest) {
        return guestDao.update(guest);
    }

    public boolean deleteGuest(int guestId) {
        return guestDao.delete(guestId);
    }

    public List<Guest> searchGuests(String keyword) {
        return guestDao.findBySearch(keyword, 0, Integer.MAX_VALUE);
    }
} 
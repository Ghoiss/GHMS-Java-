package lgq.design.jsp.service;

import lgq.design.jsp.dao.EmployeeDao;
import lgq.design.jsp.model.Employee;
import lgq.design.jsp.util.PageUtil;

import java.util.List;

public class EmployeeService {
    private EmployeeDao employeeDao = new EmployeeDao();
    
    public List<Employee> getAllEmployees() {
        return employeeDao.getAll();
    }
    
    public PageUtil<Employee> getEmployeesByPage(int page) {
        return employeeDao.getByPage(page);
    }
    
    public Employee getEmployeeById(int id) {
        return employeeDao.getById(id);
    }
    
    public boolean addEmployee(Employee employee) {
        return employeeDao.add(employee);
    }
    
    public boolean updateEmployee(Employee employee) {
        return employeeDao.update(employee);
    }
    
    public boolean deleteEmployee(int id) {
        return employeeDao.delete(id);
    }
} 
package lgq.design.jsp.util;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import lgq.design.jsp.model.*;

import java.util.List;

public class ExcelExportUtil {
    
    private static CellStyle createHeaderStyle(HSSFWorkbook workbook) {
        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        return headerStyle;
    }
    
    private static CellStyle createDataStyle(HSSFWorkbook workbook) {
        CellStyle dataStyle = workbook.createCellStyle();
        dataStyle.setAlignment(HorizontalAlignment.CENTER);
        return dataStyle;
    }
    
    private static void setColumnWidths(Sheet sheet, int... widths) {
        for (int i = 0; i < widths.length; i++) {
            sheet.setColumnWidth(i, widths[i]);
        }
    }
    
    public static HSSFWorkbook exportRooms(List<Room> rooms) {
        System.out.println("开始导出房间信息，数据条数：" + rooms.size());
        HSSFWorkbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("房间信息");
        
        setColumnWidths(sheet, 3000, 3000, 3000, 3000, 3000, 6000, 3000);
        
        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        
        // 创建标题行
        Row headerRow = sheet.createRow(0);
        String[] headers = {"房间ID", "房间号", "类型", "价格", "状态", "描述", "负责员工ID"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // 填充数据
        int rowNum = 1;
        for (Room room : rooms) {
            Row row = sheet.createRow(rowNum++);
            
            Cell[] cells = new Cell[7];
            for (int i = 0; i < cells.length; i++) {
                cells[i] = row.createCell(i);
                cells[i].setCellStyle(dataStyle);
            }
            
            cells[0].setCellValue(room.getRoomId());
            cells[1].setCellValue(room.getRoomNumber());
            cells[2].setCellValue(room.getRoomType());
            cells[3].setCellValue(room.getPrice());
            cells[4].setCellValue(room.getStatus());
            cells[5].setCellValue(room.getDescription());
            if (room.getEmployeeId() != null) {
                cells[6].setCellValue(room.getEmployeeId());
            }
        }
        
        System.out.println("房间信息导出完成");
        return workbook;
    }
    
    public static HSSFWorkbook exportReservations(List<Reservation> reservations) {
        System.out.println("开始导出预订信息，数据条数：" + reservations.size());
        HSSFWorkbook workbook = new HSSFWorkbook();
        
        try {
            Sheet sheet = workbook.createSheet("预订信息");
            
            // 设置列宽
            setColumnWidths(sheet, 3000, 3000, 3000, 4000, 4000, 3000);
            
            // 创建样式
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);
            
            // 创建标题行
            Row headerRow = sheet.createRow(0);
            String[] headers = {"预订ID", "房间ID", "用户ID", "入住日期", "退房日期", "状态"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }
            
            // 填充数据
            int rowNum = 1;
            for (Reservation reservation : reservations) {
                try {
                    Row row = sheet.createRow(rowNum++);
                    
                    // 创建并设置单元格
                    Cell[] cells = new Cell[6];
                    for (int i = 0; i < cells.length; i++) {
                        cells[i] = row.createCell(i);
                        cells[i].setCellStyle(dataStyle);
                    }
                    
                    // 设置数据
                    cells[0].setCellValue(String.valueOf(reservation.getReservationId()));
                    cells[1].setCellValue(String.valueOf(reservation.getRoomId()));
                    cells[2].setCellValue(String.valueOf(reservation.getUserId()));
                    cells[3].setCellValue(reservation.getCheckInDate() != null ? 
                        reservation.getCheckInDate().toString() : "");
                    cells[4].setCellValue(reservation.getCheckOutDate() != null ? 
                        reservation.getCheckOutDate().toString() : "");
                    cells[5].setCellValue(reservation.getStatus() != null ? 
                        reservation.getStatus() : "");
                    
                    System.out.println("写入第 " + rowNum + " 行数据");
                } catch (Exception e) {
                    System.out.println("写入第 " + rowNum + " 行数据时出错：" + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            System.out.println("预订信息导出完成");
            return workbook;
        } catch (Exception e) {
            System.out.println("创建Excel工作簿时出错：" + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("导出失败", e);
        }
    }
    
    public static HSSFWorkbook exportEmployees(List<Employee> employees) {
        System.out.println("开始导出员工信息，数据条数：" + employees.size());
        HSSFWorkbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("员工信息");
        
        setColumnWidths(sheet, 3000, 4000, 4000);
        
        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        
        // 创建标题行
        Row headerRow = sheet.createRow(0);
        String[] headers = {"员工ID", "姓名", "电话"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // 填充数据
        int rowNum = 1;
        for (Employee employee : employees) {
            Row row = sheet.createRow(rowNum++);
            
            Cell[] cells = new Cell[3];
            for (int i = 0; i < cells.length; i++) {
                cells[i] = row.createCell(i);
                cells[i].setCellStyle(dataStyle);
            }
            
            cells[0].setCellValue(employee.getEmployeeId());
            cells[1].setCellValue(employee.getName());
            cells[2].setCellValue(employee.getPhone());
        }
        
        System.out.println("员工信息导出完成");
        return workbook;
    }
    
    public static HSSFWorkbook exportGuests(List<User> guests) {
        System.out.println("开始导出客人信息，数据条数：" + guests.size());
        HSSFWorkbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("住户信息");
        
        setColumnWidths(sheet, 3000, 4000, 6000, 3000);
        
        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        
        // 创建标题行
        Row headerRow = sheet.createRow(0);
        String[] headers = {"用户ID", "用户名", "邮箱", "角色"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // 填充数据
        int rowNum = 1;
        for (User user : guests) {
            Row row = sheet.createRow(rowNum++);
            
            Cell[] cells = new Cell[4];
            for (int i = 0; i < cells.length; i++) {
                cells[i] = row.createCell(i);
                cells[i].setCellStyle(dataStyle);
            }
            
            cells[0].setCellValue(user.getUserId());
            cells[1].setCellValue(user.getUsername());
            cells[2].setCellValue(user.getEmail());
            cells[3].setCellValue(user.getRole());
        }
        
        System.out.println("客人信息导出完成");
        return workbook;
    }
} 
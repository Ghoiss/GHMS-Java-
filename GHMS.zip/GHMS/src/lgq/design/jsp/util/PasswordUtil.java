package lgq.design.jsp.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class PasswordUtil {
    public static String encrypt(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");//创建一个SHA-256算法的实例，用于生成密码的哈希值
            byte[] hash = md.digest(password.getBytes());//将输入的密码转换为字节数组并计算其哈希值，返回一个字节数组 hash
            return Base64.getEncoder().encodeToString(hash);//将字节数组编码为Base64字符串并返回。这使得哈希值更易于存储和传输。
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean verify(String password, String hashedPassword) {
        String newHash = encrypt(password);
        return newHash != null && newHash.equals(hashedPassword);
    }
}
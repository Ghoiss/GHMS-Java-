package lgq.design.jsp.service;

import lgq.design.jsp.dao.GuestDao;
import lgq.design.jsp.dao.ReservationDao;
import lgq.design.jsp.dao.RoomDao;
import lgq.design.jsp.model.Guest;
import lgq.design.jsp.model.Reservation;
import lgq.design.jsp.model.Room;
import lgq.design.jsp.util.ExcelUtil;

import java.io.OutputStream;
import java.util.List;

public class ExportService {
    private RoomDao roomDao = new RoomDao();
    private GuestDao guestDao = new GuestDao();
    private ReservationDao reservationDao = new ReservationDao();

    public void exportRooms(OutputStream out) {
        List<Room> rooms = roomDao.findAll(0, Integer.MAX_VALUE);
        ExcelUtil.exportToExcel(rooms, out, "房间信息");
    }

    public void exportGuests(OutputStream out) {
        List<Guest> guests = guestDao.findAll(0, Integer.MAX_VALUE);
        ExcelUtil.exportToExcel(guests, out, "客人信息");
    }

    public void exportReservations(OutputStream out) {
        List<Reservation> reservations = reservationDao.findAll(0, Integer.MAX_VALUE);
        ExcelUtil.exportToExcel(reservations, out, "预订信息");
    }
} 